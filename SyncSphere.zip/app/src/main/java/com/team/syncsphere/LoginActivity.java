package com.team.syncsphere;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class LoginActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private boolean hidden = false;
	private HashMap<String, Object> user_select = new HashMap<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	private TextView textview11;
	private TextView textview5;
	private LinearLayout goodName;
	private TextView textview3;
	private EditText email;
	private LinearLayout linear3;
	private TextView textview4;
	private LinearLayout linear9;
	private LinearLayout linear4;
	private LinearLayout repeatPassword;
	private LinearLayout linear8;
	private TextView login;
	private TextView singup;
	private TextView textview7;
	private TextView textview10;
	private EditText name;
	private LinearLayout linear14;
	private EditText password;
	private ImageView imageview2;
	private TextView textview9;
	private EditText confirm_password;
	private LinearLayout linear7;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference userData = _firebase.getReference("userData");
	private ChildEventListener _userData_child_listener;
	private Intent intent = new Intent();
	private Calendar cal = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		textview11 = findViewById(R.id.textview11);
		textview5 = findViewById(R.id.textview5);
		goodName = findViewById(R.id.goodName);
		textview3 = findViewById(R.id.textview3);
		email = findViewById(R.id.email);
		linear3 = findViewById(R.id.linear3);
		textview4 = findViewById(R.id.textview4);
		linear9 = findViewById(R.id.linear9);
		linear4 = findViewById(R.id.linear4);
		repeatPassword = findViewById(R.id.repeatPassword);
		linear8 = findViewById(R.id.linear8);
		login = findViewById(R.id.login);
		singup = findViewById(R.id.singup);
		textview7 = findViewById(R.id.textview7);
		textview10 = findViewById(R.id.textview10);
		name = findViewById(R.id.name);
		linear14 = findViewById(R.id.linear14);
		password = findViewById(R.id.password);
		imageview2 = findViewById(R.id.imageview2);
		textview9 = findViewById(R.id.textview9);
		confirm_password = findViewById(R.id.confirm_password);
		linear7 = findViewById(R.id.linear7);
		auth = FirebaseAuth.getInstance();
		
		textview11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				repeatPassword.setVisibility(View.VISIBLE);
				login.setVisibility(View.GONE);
				singup.setVisibility(View.VISIBLE);
				goodName.setVisibility(View.VISIBLE);
				textview11.setVisibility(View.GONE);
				textview5.setVisibility(View.VISIBLE);
				textview2.setText("Register your account");
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				repeatPassword.setVisibility(View.GONE);
				login.setVisibility(View.VISIBLE);
				singup.setVisibility(View.GONE);
				goodName.setVisibility(View.GONE);
				textview11.setVisibility(View.VISIBLE);
				textview5.setVisibility(View.GONE);
				textview2.setText("Login to your account");
			}
		});
		
		login.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (email.getText().toString().equals("") || password.getText().toString().equals("")) {
					if (email.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Fill the Email");
					}
					if (password.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Fill the password blank");
					}
				}
				else {
					auth.signInWithEmailAndPassword(email.getText().toString().trim(), password.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "wait");
				}
			}
		});
		
		singup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (name.getText().toString().equals("") || ((email.getText().toString().equals("") || password.getText().toString().equals("")) || confirm_password.getText().toString().equals(""))) {
					if (name.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Write Your name");
					}
					if (email.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Fill your Email");
					}
					if (password.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Write a password");
					}
					if (confirm_password.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Write confirm password.");
					}
				}
				else {
					if (password.getText().toString().equals(confirm_password.getText().toString())) {
						auth.createUserWithEmailAndPassword(email.getText().toString().trim(), password.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
						SketchwareUtil.showMessage(getApplicationContext(), "wait");
					}
				}
			}
		});
		
		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (hidden) {
					hidden = false;
					imageview2.setImageResource(R.drawable.pido_1);
					_ICC(imageview2, "#9e9e9e", "#9e9e9e");
					password.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
										
					confirm_password.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
				}
				else {
					hidden = true;
					imageview2.setImageResource(R.drawable.pido_2);
					_ICC(imageview2, "#2e303f", "#2e303f");
					password.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
										confirm_password.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
				}
			}
		});
		
		_userData_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userData.addChildEventListener(_userData_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					auth.signInWithEmailAndPassword(email.getText().toString(), confirm_password.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					intent.setClass(getApplicationContext(), AdminmainActivity.class);
					startActivity(intent);
					cal = Calendar.getInstance();
					user_select = new HashMap<>();
					user_select.put("date", new SimpleDateFormat("HH : mm dd MMM yyyy").format(cal.getTime()));
					user_select.put("email", FirebaseAuth.getInstance().getCurrentUser().getEmail());
					user_select.put("Uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					if (!name.getText().toString().equals("")) {
						user_select.put("name", name.getText().toString());
						user_select.put("asLeader", "");
						user_select.put("asUser", "");
					}
					userData.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(user_select);
					user_select.clear();
					finish();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		repeatPassword.setVisibility(View.VISIBLE);
		login.setVisibility(View.GONE);
		singup.setVisibility(View.VISIBLE);
		goodName.setVisibility(View.VISIBLE);
		textview11.setVisibility(View.GONE);
		textview5.setVisibility(View.VISIBLE);
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			intent.setClass(getApplicationContext(), AdminmainActivity.class);
			startActivity(intent);
			finish();
		}
		password.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
							
		confirm_password.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
	}
	
	public void _ICC(final ImageView _img, final String _c1, final String _c2) {
		_img.setImageTintList(new android.content.res.ColorStateList(new int[][] {{-android.R.attr.state_pressed},{android.R.attr.state_pressed}},new int[]{Color.parseColor(_c1), Color.parseColor(_c2)}));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}