package com.team.syncsphere;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class DesignationActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double n = 0;
	private String random_color = "";
	private String separator = "";
	private String charSeq = "";
	private String seperator = "";
	private String Item = "";
	private String item = "";
	private HashMap<String, Object> map = new HashMap<>();
	
	private ArrayList<String> liststring = new ArrayList<>();
	private ArrayList<String> randomColors = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	private ArrayList<String> stringlist = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear26;
	private LinearLayout top_item;
	private LinearLayout linear14;
	private LinearLayout linear13;
	private LinearLayout linear7;
	private TextView textview8;
	private RecyclerView recyclerview1;
	private LinearLayout linear25;
	private ImageView imageview1;
	private TextView textview13;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private TextView email;
	private TextView textview4;
	private LinearLayout linear6;
	private TextView textview5;
	private LinearLayout linear15;
	private LinearLayout linear8;
	private TextView Name;
	private ImageView imageview2;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear_label_box;
	private HorizontalScrollView hscroll2;
	private LinearLayout linear24;
	private EditText edittext2;
	private EditText edittext4;
	private TextView txt_output;
	private TextView txt_output2;
	private TextView textview7;
	private TextView textview6;
	
	private DatabaseReference Workspaces = _firebase.getReference("Workspaces");
	private ChildEventListener _Workspaces_child_listener;
	private AlertDialog.Builder dia;
	private DatabaseReference userData = _firebase.getReference("userData");
	private ChildEventListener _userData_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.designation);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear26 = findViewById(R.id.linear26);
		top_item = findViewById(R.id.top_item);
		linear14 = findViewById(R.id.linear14);
		linear13 = findViewById(R.id.linear13);
		linear7 = findViewById(R.id.linear7);
		textview8 = findViewById(R.id.textview8);
		recyclerview1 = findViewById(R.id.recyclerview1);
		linear25 = findViewById(R.id.linear25);
		imageview1 = findViewById(R.id.imageview1);
		textview13 = findViewById(R.id.textview13);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		email = findViewById(R.id.email);
		textview4 = findViewById(R.id.textview4);
		linear6 = findViewById(R.id.linear6);
		textview5 = findViewById(R.id.textview5);
		linear15 = findViewById(R.id.linear15);
		linear8 = findViewById(R.id.linear8);
		Name = findViewById(R.id.Name);
		imageview2 = findViewById(R.id.imageview2);
		hscroll1 = findViewById(R.id.hscroll1);
		linear_label_box = findViewById(R.id.linear_label_box);
		hscroll2 = findViewById(R.id.hscroll2);
		linear24 = findViewById(R.id.linear24);
		edittext2 = findViewById(R.id.edittext2);
		edittext4 = findViewById(R.id.edittext4);
		txt_output = findViewById(R.id.txt_output);
		txt_output2 = findViewById(R.id.txt_output2);
		textview7 = findViewById(R.id.textview7);
		textview6 = findViewById(R.id.textview6);
		dia = new AlertDialog.Builder(this);
		auth = FirebaseAuth.getInstance();
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				seperator = ",";
				charSeq = _charSeq.trim();
				if (charSeq.equals("") || charSeq.equals(",")) {
					
				}
				else {
					if (charSeq.contains(",")) {
						Item = charSeq.substring((int)(0), (int)(charSeq.indexOf(seperator)));
						if (liststring.contains(Item)) {
							SketchwareUtil.showMessage(getApplicationContext(), "You Already Selected this Category");
						}
						else {
							liststring.add(Item);
							n = liststring.size() - 1;
							_add_item(Item);
							edittext2.setText(charSeq.substring((int)(charSeq.indexOf(seperator) + 1), (int)(charSeq.length())));
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		edittext4.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				seperator = ",";
				charSeq = _charSeq.trim();
				if (charSeq.equals("") || charSeq.equals(",")) {
					
				}
				else {
					if (charSeq.contains(",")) {
						item = charSeq.substring((int)(0), (int)(charSeq.indexOf(seperator)));
						if (stringlist.contains(item)) {
							SketchwareUtil.showMessage(getApplicationContext(), "You Already Selected this Category");
						}
						else {
							stringlist.add(item);
							n = stringlist.size() - 1;
							_add_itemsss(item);
							edittext4.setText(charSeq.substring((int)(charSeq.indexOf(seperator) + 1), (int)(charSeq.length())));
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				map = new HashMap<>();
				map.put("asLeader", txt_output.getText().toString());
				map.put("asUser", txt_output2.getText().toString());
				userData.child(getIntent().getStringExtra("UID")).updateChildren(map);
				map.clear();
				finish();
			}
		});
		
		_Workspaces_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Workspaces.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(list));
						recyclerview1.setLayoutManager(new LinearLayoutManager(DesignationActivity.this));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Workspaces.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(list));
						recyclerview1.setLayoutManager(new LinearLayoutManager(DesignationActivity.this));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Workspaces.addChildEventListener(_Workspaces_child_listener);
		
		_userData_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userData.addChildEventListener(_userData_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)2, 0xFFE7E7E7, 0xFFFFFFFF));
		linear7.setVisibility(View.GONE);
		linear13.setVisibility(View.GONE);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinssemibold.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		email.setText(getIntent().getStringExtra("email"));
		Name.setText(getIntent().getStringExtra("name"));
		edittext2.setText(getIntent().getStringExtra("asLeader"));
		edittext4.setText(getIntent().getStringExtra("asUser"));
		_SX_CornerRadius_card(top_item, "#ffffff", 12);
		if (getIntent().getStringExtra("asLeader").equals("")) {
			imageview2.setVisibility(View.INVISIBLE);
		}
		else {
			imageview2.setVisibility(View.VISIBLE);
		}
	}
	
	@Override
	public void onBackPressed() {
		SketchwareUtil.showMessage(getApplicationContext(), "Just Do only Discard or Save");
	}
	public void _edittext(final TextView _edittext, final String _error) {
		_edittext.setError(_error);
	}
	
	
	public void _output() {
		txt_output.setVisibility(View.GONE);
		txt_output.setText("");
		n = 0;
		for(int _repeat35 = 0; _repeat35 < (int)(liststring.size()); _repeat35++) {
			if (!liststring.get((int)(n)).equals("")) {
				txt_output.setVisibility(View.VISIBLE);
				txt_output.setText(txt_output.getText().toString().concat(liststring.get((int)(n)).concat(",")));
			}
			n++;
		}
	}
	
	
	public void _setBgCorners(final View _view, final double _radius, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
		gd.setColor(Color.parseColor("#" + _color.replace("#", ""))); /* color */
		gd.setCornerRadius((int)_radius); /* radius */
		gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
		_view.setBackground(gd);
	}
	
	
	public void _randomColor() {
		randomColors.add("#FFC05F");
		randomColors.add("#FF826C");
		randomColors.add("#53D2DC");
		randomColors.add("#3196E2");
		randomColors.add("#1B2A52");
		random_color = randomColors.get((int)(SketchwareUtil.getRandom((int)(0), (int)(randomColors.size() - 1))));
	}
	
	
	public void _add_item(final String _string) {
		LinearLayout item = new LinearLayout(DesignationActivity.this);
		item.setOrientation(LinearLayout.VERTICAL);
		LayoutInflater inflater = getLayoutInflater();
		View convertView = (View) inflater.inflate(R.layout.label_item, null);
		
		LinearLayout linear_label = (LinearLayout) convertView.findViewById(R.id.linear_label);
		
		TextView txt = (TextView) convertView.findViewById(R.id.txt_label);
		
		ImageView img_remove = (ImageView) convertView.findViewById(R.id.img_remove);
		
		final int position = (int) n;
		linear_label_box.addView(convertView);
		_randomColor();
		_setBgCorners(linear_label,30,random_color);
		linear_label.setElevation(7);
		txt.setText(_string);
		linear_label.setOnClickListener(new View.OnClickListener(){
			    public void onClick(View v){
				
				v.setVisibility(View.GONE);
				liststring.remove((int) position);
				liststring.add((int) position, "");
				
				/* the value "" will be counted as nothing */
				_output();
			}
		});
		_output();
		/*It will automatically scroll to end*/ ;
		hscroll1.post(new Runnable() { 
			        public void run() { 
				      hscroll1.fullScroll(hscroll1.FOCUS_RIGHT);
				
				        } 
		});
	}
	
	
	public void _outputsss() {
		txt_output2.setVisibility(View.GONE);
		txt_output2.setText("");
		n = 0;
		for(int _repeat11 = 0; _repeat11 < (int)(stringlist.size()); _repeat11++) {
			if (!stringlist.get((int)(n)).equals("")) {
				txt_output2.setVisibility(View.VISIBLE);
				txt_output2.setText(txt_output2.getText().toString().concat(stringlist.get((int)(n)).concat(",")));
			}
			n++;
		}
	}
	
	
	public void _add_itemsss(final String _string) {
		LinearLayout item = new LinearLayout(DesignationActivity.this);
		item.setOrientation(LinearLayout.VERTICAL);
		LayoutInflater inflater = getLayoutInflater();
		View convertView = (View) inflater.inflate(R.layout.label_item, null);
		
		LinearLayout linear_label = (LinearLayout) convertView.findViewById(R.id.linear_label);
		
		TextView txt = (TextView) convertView.findViewById(R.id.txt_label);
		
		ImageView img_remove = (ImageView) convertView.findViewById(R.id.img_remove);
		
		final int position = (int) n;
		linear24.addView(convertView);
		_randomColor();
		_setBgCorners(linear_label,30,random_color);
		linear_label.setElevation(7);
		txt.setText(_string);
		linear_label.setOnClickListener(new View.OnClickListener(){
			    public void onClick(View v){
				
				v.setVisibility(View.GONE);
				stringlist.remove((int) position);
				stringlist.add((int) position, "");
				
				/* the value "" will be counted as nothing */
				_outputsss();
			}
		});
		_outputsss();
		/*It will automatically scroll to end*/ ;
		hscroll2.post(new Runnable() { 
			        public void run() { 
				      hscroll2.fullScroll(hscroll2.FOCUS_RIGHT);
				
				        } 
		});
	}
	
	
	public void _SX_CornerRadius_card(final View _view, final String _color, final double _value) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation(5);
		}
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.workspaces_list, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final TextView textview17 = _view.findViewById(R.id.textview17);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview11 = _view.findViewById(R.id.textview11);
			final TextView textview12 = _view.findViewById(R.id.textview12);
			final TextView textview13 = _view.findViewById(R.id.textview13);
			final TextView textview14 = _view.findViewById(R.id.textview14);
			final TextView textview15 = _view.findViewById(R.id.textview15);
			final TextView textview16 = _view.findViewById(R.id.textview16);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)2, 0xFFE7E7E7, 0xFFFFFFFF));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinssemibold.ttf"), 0);
			textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview15.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview16.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview17.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			if (list.get((int)_position).containsKey("workspaceN")) {
				textview1.setText(list.get((int)_position).get("workspaceN").toString());
			}
			textview11.setVisibility(View.GONE);
			textview12.setVisibility(View.GONE);
			linear4.setVisibility(View.GONE);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					dia.setMessage("What did you want to do?");
					dia.setPositiveButton("Add as User", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							edittext4.setText(list.get((int)_position).get("workspaceN").toString().concat(","));
						}
					});
					dia.setNegativeButton("Add as Leader", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							edittext2.setText(list.get((int)_position).get("workspaceN").toString().concat(","));
						}
					});
					dia.create().show();
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}