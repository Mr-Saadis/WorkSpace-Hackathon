package com.team.syncsphere;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class TaskviewerActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String UID = "";
	private String TEAM = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String startTime = "";
	private String Time = "";
	private String Start = "";
	private String TIME = "";
	private String Totaltime = "";
	private double calculate = 0;
	private HashMap<String, Object> mapq = new HashMap<>();
	private String uid = "";
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear11;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private LinearLayout top_item;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private TextView textview13;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout separatir;
	private LinearLayout linear8;
	private LinearLayout seperator;
	private TextView textview11;
	private TextView textview30;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear7;
	private LinearLayout linear6;
	private TextView textview19;
	private TextView textview17;
	private TextView textview18;
	private LinearLayout linear10;
	private LinearLayout linear9;
	private TextView textview12;
	private TextView textview1;
	private TextView textview20;
	private LinearLayout linear27;
	private TextView textview31;
	private LinearLayout linear16;
	private LinearLayout linear15;
	private TextView textview22;
	private LinearLayout linear17;
	private TextView textview26;
	private TextView textview23;
	private TextView textview24;
	private LinearLayout linear18;
	private TextView textview27;
	private TextView textview25;
	private RecyclerView recyclerview1;
	private LinearLayout linear22;
	private TextView textview28;
	private LinearLayout linear21;
	private TextView textview29;
	private LinearLayout linear23;
	private LinearLayout linear24;
	
	private DatabaseReference team = _firebase.getReference("+team+");
	private ChildEventListener _team_child_listener;
	private Calendar cal = Calendar.getInstance();
	private Calendar c = Calendar.getInstance();
	private DatabaseReference time = _firebase.getReference("+time+");
	private ChildEventListener _time_child_listener;
	private AlertDialog.Builder dia;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.taskviewer);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear11 = findViewById(R.id.linear11);
		linear19 = findViewById(R.id.linear19);
		linear20 = findViewById(R.id.linear20);
		top_item = findViewById(R.id.top_item);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		textview13 = findViewById(R.id.textview13);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		separatir = findViewById(R.id.separatir);
		linear8 = findViewById(R.id.linear8);
		seperator = findViewById(R.id.seperator);
		textview11 = findViewById(R.id.textview11);
		textview30 = findViewById(R.id.textview30);
		linear25 = findViewById(R.id.linear25);
		linear26 = findViewById(R.id.linear26);
		linear7 = findViewById(R.id.linear7);
		linear6 = findViewById(R.id.linear6);
		textview19 = findViewById(R.id.textview19);
		textview17 = findViewById(R.id.textview17);
		textview18 = findViewById(R.id.textview18);
		linear10 = findViewById(R.id.linear10);
		linear9 = findViewById(R.id.linear9);
		textview12 = findViewById(R.id.textview12);
		textview1 = findViewById(R.id.textview1);
		textview20 = findViewById(R.id.textview20);
		linear27 = findViewById(R.id.linear27);
		textview31 = findViewById(R.id.textview31);
		linear16 = findViewById(R.id.linear16);
		linear15 = findViewById(R.id.linear15);
		textview22 = findViewById(R.id.textview22);
		linear17 = findViewById(R.id.linear17);
		textview26 = findViewById(R.id.textview26);
		textview23 = findViewById(R.id.textview23);
		textview24 = findViewById(R.id.textview24);
		linear18 = findViewById(R.id.linear18);
		textview27 = findViewById(R.id.textview27);
		textview25 = findViewById(R.id.textview25);
		recyclerview1 = findViewById(R.id.recyclerview1);
		linear22 = findViewById(R.id.linear22);
		textview28 = findViewById(R.id.textview28);
		linear21 = findViewById(R.id.linear21);
		textview29 = findViewById(R.id.textview29);
		linear23 = findViewById(R.id.linear23);
		linear24 = findViewById(R.id.linear24);
		dia = new AlertDialog.Builder(this);
		
		linear26.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "working pending...");
			}
		});
		
		linear17.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				cal = Calendar.getInstance();
				map.put("startTime", new SimpleDateFormat("hh:mm").format(cal.getTime()));
				map.put("Time", String.valueOf((long)(cal.getTimeInMillis())));
				map.put("Start", "In progress");
				team.child(UID).updateChildren(map);
				textview26.setText(new SimpleDateFormat("hh:mm").format(cal.getTime()));
				textview20.setText("In progress");
				textview20.setTextColor(0xFF56549E);
				linear18.setEnabled(true);
				linear17.setEnabled(false);
				linear17.setAlpha((float)(.7d));
				linear18.setAlpha((float)(1));
				cal.setTimeInMillis((long)(0));
				finish();
			}
		});
		
		linear18.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				team.addChildEventListener(_team_child_listener);
				dia.setMessage("Progress of your task?");
				dia.setPositiveButton("Pause", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						cal.setTimeInMillis((long)(Double.parseDouble(Time)));
						c = Calendar.getInstance();
						calculate = (long)(c.getTimeInMillis() - cal.getTimeInMillis());
						map.put("Totaltime", String.valueOf((long)(Double.parseDouble(Totaltime) + calculate)));
						map.put("Start", "pending");
						textview20.setText("pending");
						textview20.setTextColor(0xFFFF9E9E);
						team.child(UID).updateChildren(map);
						map.clear();
						textview27.setText(new SimpleDateFormat("hh:mm").format(cal.getTime()));
						linear18.setEnabled(false);
						linear17.setEnabled(true);
						linear18.setAlpha((float)(.7d));
						linear17.setAlpha((float)(1));
						mapq = new HashMap<>();
						uid = time.push().getKey();
						mapq.put("startTime", startTime);
						mapq.put("endTime", new SimpleDateFormat("hh:mm").format(c.getTime()));
						time.child(uid).updateChildren(mapq);
						mapq.clear();
					}
				});
				dia.setNegativeButton("Completed", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						cal.setTimeInMillis((long)(Double.parseDouble(Time)));
						c = Calendar.getInstance();
						calculate = (long)(c.getTimeInMillis() - cal.getTimeInMillis());
						map.put("Totaltime", String.valueOf((long)(Double.parseDouble(Totaltime) + calculate)));
						map.put("Start", "Completed");
						textview20.setText("Completed");
						textview20.setTextColor(0xFF72CEC1);
						team.child(UID).updateChildren(map);
						map.clear();
						textview27.setText(new SimpleDateFormat("hh:mm").format(cal.getTime()));
						linear18.setEnabled(false);
						linear17.setEnabled(false);
						linear18.setAlpha((float)(.7d));
						linear17.setAlpha((float)(.7d));
						mapq = new HashMap<>();
						uid = time.push().getKey();
						mapq.put("startTime", startTime);
						mapq.put("endTime", new SimpleDateFormat("hh:mm").format(c.getTime()));
						time.child(uid).updateChildren(mapq);
						mapq.clear();
					}
				});
				dia.create().show();
			}
		});
		
		textview28.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_TransitionManager(linear1, 500);
				_Animator(linear11, "translationY", SketchwareUtil.getDip(getApplicationContext(), (int)(0)), 500);
				return true;
			}
		});
		
		textview28.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(linear1, 500);
				_Animator(linear11, "translationY", SketchwareUtil.getDip(getApplicationContext(), (int)(-180)), 500);
				_Animator(linear19, "translationY", SketchwareUtil.getDip(getApplicationContext(), (int)(0)), 100);
				SketchwareUtil.showMessage(getApplicationContext(), "Long press to hide");
			}
		});
		
		textview29.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_TransitionManager(linear1, 500);
				_Animator(linear19, "translationY", SketchwareUtil.getDip(getApplicationContext(), (int)(0)), 500);
				return true;
			}
		});
		
		textview29.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(linear1, 500);
				_Animator(linear19, "translationY", SketchwareUtil.getDip(getApplicationContext(), (int)(-420)), 500);
				_Animator(linear11, "translationY", SketchwareUtil.getDip(getApplicationContext(), (int)(0)), 500);
				SketchwareUtil.showMessage(getApplicationContext(), "Long Press to hide");
			}
		});
		
		_team_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(UID)) {
					if (_childValue.containsKey("startTime")) {
						startTime = _childValue.get("startTime").toString();
						Time = _childValue.get("Time").toString();
						Start = _childValue.get("Start").toString();
						Totaltime = _childValue.get("Totaltime").toString();
						if (Start.equals("In progress")) {
							linear18.setEnabled(true);
							linear17.setEnabled(false);
							linear17.setAlpha((float)(.7d));
							linear18.setAlpha((float)(1));
						}
						else {
							if (Start.equals("pending")) {
								linear18.setEnabled(false);
								linear17.setEnabled(true);
								linear18.setAlpha((float)(.7d));
								linear17.setAlpha((float)(1));
							}
							else {
								linear18.setEnabled(false);
								linear17.setEnabled(false);
								linear18.setAlpha((float)(.7d));
								linear17.setAlpha((float)(.7d));
							}
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		team.addChildEventListener(_team_child_listener);
		
		_time_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				time.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(list));
						recyclerview1.setLayoutManager(new LinearLayoutManager(TaskviewerActivity.this));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				time.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(list));
						recyclerview1.setLayoutManager(new LinearLayoutManager(TaskviewerActivity.this));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		time.addChildEventListener(_time_child_listener);
	}
	
	private void initializeLogic() {
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		textview30.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		_SX_CornerRadius_card(top_item, "#ffffff", 12);
		textview12.setText("Due : ".concat(getIntent().getStringExtra("deadline")));
		textview11.setText(getIntent().getStringExtra("taskD"));
		textview1.setText(getIntent().getStringExtra("taskN"));
		textview17.setText(getIntent().getStringExtra("taskT"));
		textview17.setText(getIntent().getStringExtra("uploadedby"));
		textview19.setText(getIntent().getStringExtra("uploadedby").substring((int)(0), (int)(1)));
		linear17.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)0, 0xFFE7E7E7, 0xFF56549E));
		linear18.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)0, 0xFFFF9E9E, 0xFFFF9E9E));
		UID = getIntent().getStringExtra("TaskUID");
		linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, 0xFFFF9E9E));
		team.removeEventListener(_team_child_listener);
		TEAM = getIntent().getStringExtra("TEAM");
		team = _firebase.getReference(TEAM);
		team.addChildEventListener(_team_child_listener);
		time.removeEventListener(_time_child_listener);
		TIME = "Time/".concat(UID);
		time = _firebase.getReference(TIME);
		time.addChildEventListener(_time_child_listener);
		textview20.setText(getIntent().getStringExtra("Start"));
		if ("In progress".equals(getIntent().getStringExtra("Start"))) {
			textview20.setTextColor(0xFF56549E);
		}
		else {
			if ("pending".equals(getIntent().getStringExtra("Start"))) {
				textview20.setTextColor(0xFFFF9E9E);
			}
			else {
				textview20.setTextColor(0xFF72CEC1);
			}
		}
	}
	
	public void _SX_CornerRadius_card(final View _view, final String _color, final double _value) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation(5);
		}
	}
	
	
	public void _ICC(final ImageView _img, final String _c1, final String _c2) {
		_img.setImageTintList(new android.content.res.ColorStateList(new int[][] {{-android.R.attr.state_pressed},{android.R.attr.state_pressed}},new int[]{Color.parseColor(_c1), Color.parseColor(_c2)}));
	}
	
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _Animator(final View _view, final String _propertyName, final double _value, final double _duration) {
		ObjectAnimator anim = new ObjectAnimator();
		anim.setTarget(_view);
		anim.setPropertyName(_propertyName);
		anim.setFloatValues((float)_value);
		anim.setDuration((long)_duration);
		anim.start();
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.timelabs, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)2, 0xFFE7E7E7, 0xFFFFFFFF));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinssemibold.ttf"), 0);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			if (list.get((int)_position).containsKey("startTime")) {
				textview4.setText(list.get((int)_position).get("startTime").toString());
			}
			if (list.get((int)_position).containsKey("endTime")) {
				textview5.setText(list.get((int)_position).get("endTime").toString());
			}
			textview1.setText("Time Lab ".concat(String.valueOf((long)(_position + 1))));
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}