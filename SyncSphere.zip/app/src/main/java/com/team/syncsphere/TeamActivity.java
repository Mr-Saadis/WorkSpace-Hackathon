package com.team.syncsphere;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class TeamActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String TEAM = "";
	private String username = "";
	private String leaders = "";
	private String users = "";
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout top_item;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ImageView imageview2;
	private TextView textview13;
	private ImageView imageview1;
	private TextView textview4;
	private RecyclerView recyclerview1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private TextView textview2;
	private TextView textview3;
	
	private DatabaseReference team = _firebase.getReference("+team+");
	private ChildEventListener _team_child_listener;
	private Intent in = new Intent();
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.team);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		top_item = findViewById(R.id.top_item);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		imageview2 = findViewById(R.id.imageview2);
		textview13 = findViewById(R.id.textview13);
		imageview1 = findViewById(R.id.imageview1);
		textview4 = findViewById(R.id.textview4);
		recyclerview1 = findViewById(R.id.recyclerview1);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		
		linear7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), CreatetaskActivity.class);
				in.putExtra("UID", getIntent().getStringExtra("UID"));
				in.putExtra("username", username);
				startActivity(in);
			}
		});
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), TeamChatActivity.class);
				i.putExtra("username", username);
				i.putExtra("UID", getIntent().getStringExtra("UID"));
				startActivity(i);
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), TeammembersssActivity.class);
				i.putExtra("Leaders", leaders);
				i.putExtra("Users", users);
				startActivity(i);
			}
		});
		
		_team_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				team.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(list));
						recyclerview1.setLayoutManager(new LinearLayoutManager(TeamActivity.this));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				team.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						recyclerview1.setAdapter(new Recyclerview1Adapter(list));
						recyclerview1.setLayoutManager(new LinearLayoutManager(TeamActivity.this));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		team.addChildEventListener(_team_child_listener);
	}
	
	private void initializeLogic() {
		linear7.setVisibility(View.GONE);
		_GradientDrawable(linear7, 30, 1, 3, "#ffffff", "#e7e7e7", false, true, 200);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
		_GradientDrawable(linear5, 30, 0, 3, "#72cec1", "#e7e7e7", false, true, 200);
		_GradientDrawable(linear6, 30, 0, 3, "#ff9e9e", "#e7e7e7", false, true, 200);
		textview1.setText(getIntent().getStringExtra("workspaceN"));
		username = getIntent().getStringExtra("username");
		team.removeEventListener(_team_child_listener);
		TEAM = "Teams/".concat(getIntent().getStringExtra("UID"));
		team = _firebase.getReference(TEAM);
		team.addChildEventListener(_team_child_listener);
		_SX_CornerRadius_card(top_item, "#ffffff", 12);
		leaders = getIntent().getStringExtra("Leaders");
		users = getIntent().getStringExtra("Users");
		if (leaders.contains(username)) {
			linear7.setVisibility(View.VISIBLE);
		}
		else {
			linear7.setVisibility(View.GONE);
		}
	}
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9e9e9e")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		}
		else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.97f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.97f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _SX_CornerRadius_card(final View _view, final String _color, final double _value) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation(5);
		}
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.task_list, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final LinearLayout separatir = _view.findViewById(R.id.separatir);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final TextView textview11 = _view.findViewById(R.id.textview11);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final TextView textview19 = _view.findViewById(R.id.textview19);
			final TextView textview17 = _view.findViewById(R.id.textview17);
			final TextView textview18 = _view.findViewById(R.id.textview18);
			final TextView textview20 = _view.findViewById(R.id.textview20);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview12 = _view.findViewById(R.id.textview12);
			final TextView textview15 = _view.findViewById(R.id.textview15);
			final TextView textview16 = _view.findViewById(R.id.textview16);
			
			_GradientDrawable(linear1, 30, 2, 0, "#ffffff", "#e7e7e7", false, true, 200);
			linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, 0xFFFF9E9E));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinssemibold.ttf"), 0);
			textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			
			
			
			
			textview20.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppinsmedium.ttf"), 0);
			if (list.get((int)_position).containsKey("taskN")) {
				textview1.setText(list.get((int)_position).get("taskN").toString());
				textview16.setText(new DecimalFormat("0.0").format(Double.parseDouble(list.get((int)_position).get("Totaltime").toString()) / 60000));
			}
			if (list.get((int)_position).containsKey("taskD")) {
				textview11.setText(list.get((int)_position).get("taskD").toString());
			}
			if (list.get((int)_position).containsKey("taskT")) {
				textview18.setText(list.get((int)_position).get("taskT").toString());
			}
			if (list.get((int)_position).containsKey("uploadedby")) {
				textview17.setText(list.get((int)_position).get("uploadedby").toString());
				textview19.setText(list.get((int)_position).get("uploadedby").toString().substring((int)(0), (int)(1)));
			}
			if (list.get((int)_position).containsKey("deadline")) {
				textview12.setText("Deadline: ".concat(list.get((int)_position).get("deadline").toString()));
			}
			if (list.get((int)_position).containsKey("Start")) {
				textview20.setText(list.get((int)_position).get("Start").toString());
				if ("In progress".equals(list.get((int)_position).get("Start").toString())) {
					textview20.setTextColor(0xFF56549E);
				}
				else {
					if ("pending".equals(list.get((int)_position).get("Start").toString())) {
						textview20.setTextColor(0xFFFF9E9E);
					}
					else {
						textview20.setTextColor(0xFF72CEC1);
					}
				}
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					in.setClass(getApplicationContext(), TaskviewerActivity.class);
					in.putExtra("taskN", list.get((int)_position).get("taskN").toString());
					in.putExtra("taskD", list.get((int)_position).get("taskD").toString());
					in.putExtra("taskT", list.get((int)_position).get("taskT").toString());
					in.putExtra("uploadedby", list.get((int)_position).get("uploadedby").toString());
					in.putExtra("deadline", list.get((int)_position).get("deadline").toString());
					in.putExtra("TaskUID", list.get((int)_position).get("UID").toString());
					in.putExtra("taskE", list.get((int)_position).get("taskE").toString());
					in.putExtra("Start", list.get((int)_position).get("Start").toString());
					in.putExtra("TEAM", TEAM);
					startActivity(in);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}