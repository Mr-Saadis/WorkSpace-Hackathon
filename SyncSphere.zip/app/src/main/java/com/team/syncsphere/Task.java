package com.team.syncsphere;

import java.time.Duration;
import java.time.LocalDateTime;

public class Task {
    private String taskName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Duration taskDuration = Duration.ZERO;

    public Task(String taskName) {
        this.taskName = taskName;
    }

    public void startTask() {
        startTime = LocalDateTime.now();
        System.out.println("Task '" + taskName + "' started at: " + startTime);
    }

    public void stopTask() {
        if (startTime != null) {
            endTime = LocalDateTime.now();
            Duration sessionDuration = Duration.between(startTime, endTime);
            taskDuration = taskDuration.plus(sessionDuration);
            System.out.println("Task '" + taskName + "' stopped at: " + endTime);
            System.out.println("Session duration: " + sessionDuration.toMinutes() + " minutes.");
            startTime = null;  // Reset start time for next session
        } else {
            System.out.println("Task not started yet!");
        }
    }

    public Duration getTotalDuration() {
        return taskDuration;
    }
}